//
//  ViewController.swift
//  test
//
//  Created by apcsp on 11/15/16.
//  Copyright © 2016 apcsp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
	
	override func viewDidLoad() {
		super.viewDidLoad()
	}
	
	@IBAction func onBurger() {
        (tabBarController as! TabBarController).sidebar.showInViewController(self, animated: true)
    }
}

